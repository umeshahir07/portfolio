import experience from "./data/experience.json";

const Experience = () => {
  return (
    <>
      <div className="container ex" id="experience">
       
      </div>
    </>
  );
};

export default Experience;
